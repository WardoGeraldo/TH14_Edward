﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace TH14_Edward_GK
{
    public partial class Form1 : Form
    {
        MySqlConnection sqlConnection;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;
        DataTable dtTeam = new DataTable();
        DataTable dtAway = new DataTable();
        DataTable players = new DataTable();
        DataTable dt = new DataTable();
        DataTable dmatch = new DataTable();
        string SqlQuery;
        string homeID;
        string awayID;
        string teamID;
        int index = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            tb_MatchID.Enabled = false;
            sqlConnection = new MySqlConnection("server=localhost;uid=root;pwd=Papamama18;database=premier_league");
            dtTeam = new DataTable();
            dtAway = new DataTable();
            SqlQuery = "select team_id, team_name from team t";
            sqlCommand = new MySqlCommand(SqlQuery, sqlConnection);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtTeam);
            sqlDataAdapter.Fill(dtAway);
            cbTHome.DataSource = dtTeam;
            cbTHome.DisplayMember = "team_name";
            cbTHome.ValueMember = "team_id";
            cbTHome.SelectedIndex = -1;
            cbTAway.DataSource = dtAway;
            cbTAway.DisplayMember = "team_name";
            cbTAway.ValueMember = "team_id";
            cbTAway.SelectedIndex = -1;
            dt.Columns.Add("Minute");
            dt.Columns.Add("Team");
            dt.Columns.Add("Player");
            dt.Columns.Add("Type");

            dmatch = new DataTable();
            dmatch.Columns.Add("match_id");
            dmatch.Columns.Add("minute");
            dmatch.Columns.Add("team_id");
            dmatch.Columns.Add("player_id");
            dmatch.Columns.Add("type");
            dmatch.Columns.Add("delete");
        }

        private void cbTHome_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbTHome.SelectedIndex == -1 && cbTAway.SelectedIndex == -1)
            {

            }
            else
            {
                if (cbTAway.Text == cbTHome.Text)
                {
                    MessageBox.Show("Team Home tidk boleh sama");
                    cbTAway.SelectedIndex = -1;
                    cbTHome.SelectedIndex = -1;
                }
                else
                {
                    cbTeam.Items.Clear();
                    homeID = Convert.ToString(cbTHome.SelectedValue);
                    awayID = Convert.ToString(cbTAway.SelectedValue);
                    cbTeam.Items.Add(cbTHome.Text);
                    cbTeam.Items.Add(cbTAway.Text);

                }
            }
        }

        private void dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            index = e.RowIndex;
        }

        private void dTime_ValueChanged(object sender, EventArgs e)
        {
            int date = Convert.ToInt32(dTime.Value.Day);
            int month = Convert.ToInt32(dTime.Value.Month);
            int year = Convert.ToInt32(dTime.Value.Year);
            bool cek = false;
            if (year < 2016)
            {
                MessageBox.Show("Tahun tidak boleh lebih kecil dari tahun 2016");
            }
            if (year == 2016)
            {
                if (month < 2)
                {
                    MessageBox.Show("ERROR");
                }
                if (month == 2)
                {
                    if (date >= 15)
                    {
                        cek = true;
                    }
                    else if (date <= 14)
                    {
                        MessageBox.Show("ERROR");
                    }
                }
                if (month > 2)
                {
                    cek = true;
                }
            }
            if (year > 2016)
            {
                cek = true;
            }
            string tahun = dTime.Value.Year.ToString();
            SqlQuery = $"select count(match_id) from `match` where match_id like '{tahun}%';";
            sqlCommand = new MySqlCommand(SqlQuery, sqlConnection);
            DataTable dtCount = new DataTable();
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtCount);

            if (Convert.ToInt32(dtCount.Rows[0][0]) < 10)
            {
                tb_MatchID.Text = $"{tahun}00{(Convert.ToInt32(dtCount.Rows[0][0]) + 1).ToString()}";

            }
            else if (Convert.ToInt32(dtCount.Rows[0][0]) >= 10 && Convert.ToInt32(dtCount.Rows[0][0]) < 100)
            {
                tb_MatchID.Text = $"{tahun}0{(Convert.ToInt32(dtCount.Rows[0][0]) + 1).ToString()}";
            }
            else if (Convert.ToInt32(dtCount.Rows[0][0]) >= 100)
            {
                tb_MatchID.Text = $"{tahun}{(Convert.ToInt32(dtCount.Rows[0][0]) + 1).ToString()}";
            }
        }

        private void cbTAway_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbTHome.SelectedIndex == -1 && cbTAway.SelectedIndex == -1)
            {

            }
            else
            {
                if (cbTAway.Text == cbTHome.Text)
                {
                    MessageBox.Show("Team Home tidak boleh sama");
                }
                else
                {
                    cbTeam.Items.Clear();
                    homeID = Convert.ToString(cbTHome.SelectedValue);
                    awayID = Convert.ToString(cbTAway.SelectedValue);
                    cbTeam.Items.Add(cbTHome.Text);
                    cbTeam.Items.Add(cbTAway.Text);

                }
            }
        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            dt.Rows.Add(tb_Minute.Text, cbTeam.Text, cbPlayer.Text, cbType.Text);
            dgv.DataSource = dt;
            dmatch.Rows.Add(tb_MatchID.Text, tb_Minute.Text, teamID, cbPlayer.SelectedValue, cbType.Text, 0);
        }

        private void cbTeam_SelectedIndexChanged(object sender, EventArgs e)
        {
            players = new DataTable();
            if (cbTeam.SelectedIndex == 0)
            {
                teamID = homeID;
            }
            if (cbTeam.SelectedIndex == 1)
            {
                teamID = awayID;
            }
            SqlQuery = $"select player_id, player_name from player where team_id like '%{teamID}%'";
            sqlCommand = new MySqlCommand(SqlQuery, sqlConnection);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(players);
            cbPlayer.DataSource = players;
            cbPlayer.DisplayMember = "player_name";
            cbPlayer.ValueMember = "player_id";

        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            dt.Rows.RemoveAt(index);
            dgv.DataSource = dt;
            dmatch.Rows.RemoveAt(index);
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {
                sqlConnection.Open();
                for (int i = 0; i < dmatch.Rows.Count; i++)
                {
                    SqlQuery = $"insert into dmatch values ({dmatch.Rows[i][0]}, {dmatch.Rows[i][1]}, '{dmatch.Rows[i][2]}', '{dmatch.Rows[i][3]}', '{dmatch.Rows[i][4]}', {dmatch.Rows[i][5]});";
                    sqlCommand = new MySqlCommand(SqlQuery, sqlConnection);
                    sqlCommand.ExecuteNonQuery();
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            int scorehome = 0;
            int scoreaway = 0;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (dt.Rows[i][1].ToString() == cbTHome.Text)
                {
                    if (dt.Rows[i][3].ToString() == "GO" || dt.Rows[i][3].ToString() == "GP")
                    {
                        scorehome++;
                    }
                    else if (dt.Rows[i][3].ToString() == "GW")
                    {
                        scoreaway++;
                    }
                }
                else
                {
                    if (dt.Rows[i][3].ToString() == "GO" || dt.Rows[i][3].ToString() == "GP")
                    {
                        scoreaway++;
                    }
                    else if (dt.Rows[i][3].ToString() == "GW")
                    {
                        scorehome++;
                    }
                }
            }
            try
            {
                SqlQuery = $"insert into `match` values ('{tb_MatchID.Text}', '{dTime.Value.ToString("yyyy-MM-dd")}', '{homeID}', '{awayID}', {scorehome}, {scoreaway}, 'M002', 0);";
                sqlCommand = new MySqlCommand(SqlQuery, sqlConnection);
                sqlCommand.ExecuteNonQuery();
                sqlConnection.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
